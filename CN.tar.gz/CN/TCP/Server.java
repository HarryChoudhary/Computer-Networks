import java.net.*;
import java.io.*;

public class Server
{
	public static void main(String args[])throws Exception{

	String S1 = "";
	String S2 = "";

	ServerSocket ss = new ServerSocket(1045);
	Socket s = ss.accept();
	DataInputStream Din = new DataInputStream(s.getInputStream());
	DataOutputStream Dout = new DataOutputStream(s.getOutputStream()); 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
	
	while(!S1.equals("Bye"))
		{
			S2 = Din.readUTF();			
			System.out.println("Client says :"+S2);			
			S1 = br.readLine();
			Dout.writeUTF(S1);	
		}
		s.close();
		Dout.close();
	}
}
 
