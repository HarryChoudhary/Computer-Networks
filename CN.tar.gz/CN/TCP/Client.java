import java.net.*;
import java.io.*;

public class Client
{
	public static void main(String args[])throws Exception{

	String S1 = "";
	String S2 = "";

	Socket s = new Socket("localhost",1045);
	DataInputStream Din = new DataInputStream(s.getInputStream());
	DataOutputStream Dout = new DataOutputStream(s.getOutputStream()); 
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
	
	while(!S1.equals("Bye"))
		{
			S1 = br.readLine();
			Dout.writeUTF(S1);
			S2 = Din.readUTF();
			System.out.println("Server says :"+S2);
		}
		s.close();
		Dout.close();
	}
}
 
