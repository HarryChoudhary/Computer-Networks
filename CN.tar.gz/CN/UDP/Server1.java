import java.net.*;
import java.io.*;
import java.nio.charset.*;

public class Server1 {
	public static void main(String args[]) throws Exception {
		DatagramSocket s = new DatagramSocket(1070);
		InetAddress addr = InetAddress.getByName("10.12.0.72");
		InetAddress addr1 = InetAddress.getByName("10.12.0.74");
		InetAddress addr2 = InetAddress.getByName("10.12.0.231");
		InetAddress addr3 = InetAddress.getByName("10.12.0.245");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str1 = "";
		String str2 = "";
		byte[] buf = new byte[20];
		byte[] buf1 = new byte[20];
		while(!str2.equals("Bye"))
		{
			DatagramPacket p1 = new DatagramPacket(buf1,buf1.length);
			s.receive(p1);
			buf1 = p1.getData();
			str1 = new String(buf1,StandardCharsets.UTF_8);
			System.out.println("Client says :"+str1);			
		
			str2 = br.readLine();
			buf = str2.getBytes();
			DatagramPacket p2 = new DatagramPacket(buf,buf.length,addr,1060);
			DatagramPacket p3 = new DatagramPacket(buf,buf.length,addr1,1060);
			DatagramPacket p4 = new DatagramPacket(buf,buf.length,addr2,1060);
			DatagramPacket p5 = new DatagramPacket(buf,buf.length,addr3,1060);
			s.send(p2);
			s.send(p3);
			s.send(p4);
			s.send(p5);
			
		}	
	  }
	}
